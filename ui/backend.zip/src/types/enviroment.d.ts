export interface ProcessEnv {
	[key: string]: string | undefined;
}
