export interface instructorForm{
    userId:number;
    name:string;
    companyName:string;
    email:string;
    dateStart:string;
    dateEnd:string;
    trainingType:string;
    stack:string;
    isDeleted:boolean;
}