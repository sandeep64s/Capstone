export type AttendanceType = {
    date?: Date;
    session?: string;
    trainingId?: string;
    traineesPresent?: [number];
}
//

